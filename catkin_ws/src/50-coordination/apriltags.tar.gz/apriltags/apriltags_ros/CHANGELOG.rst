^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package apriltags_ros
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.2 (2016-07-06)
------------------
* Added parameter for selecting tag family
* Update the example launch file
  Added the topics that needs to be remapped to avoid looking up in the code, as well as using a compressed version of the video stream.
* Contributors: Brent Yi, Daniel Angelov

0.1.1 (2014-11-14)
------------------
* Updated author and website
* Contributors: Mitchell Wills

0.1.0 (2014-11-08)
------------------
* Updated dependancies for indigo
* Contributors: Mitchell Wills

0.0.3 (2014-11-08)
------------------
* Added info to package.xml
* Contributors: Mitchell Wills

0.0.2 (2014-10-31)
------------------
* Did some small cleanup and renaming to topics
  Added the package ros wiki urls
  Added example launch file
* Contributors: Mitchell Wills

0.0.1 (2014-10-27)
------------------
* Initial Version
